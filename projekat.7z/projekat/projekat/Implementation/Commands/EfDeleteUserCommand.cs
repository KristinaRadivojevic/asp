﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.Commands;
using Application.Exceptions;
using DataAccess;

namespace Commands
{
    public class EfDeleteUserCommand : IDeleteUserCommand
    {
        private readonly TelefoniContext _context;

        public EfDeleteUserCommand(TelefoniContext context)
        {
            _context = context;
        }

        public void Execute(int request)
        {
            var user = _context.Users.Find(request);

            if (user == null)
            {
                throw new EntityNotFoundException("User");
            }

            _context.Users.Remove(user);

            _context.SaveChanges();
        }
    }
}
