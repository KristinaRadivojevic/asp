﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Application.Commands;
using Application.DTO;
using Application.Searches;
using DataAccess;

namespace Commands
{
    public class EfGetUserCommand : IGetUserCommand
    {
        private readonly TelefoniContext _context;

        public EfGetUserCommand(TelefoniContext context)
        {
            _context = context;
        }

        public IEnumerable<GetUserDto> Execute(UserSearches request)
        {
            var user = _context.Users.AsQueryable();

            if (request.FirstName != null)
            {
                user = user.Where(u => u.FirstName.ToLower() == request.FirstName.Trim().ToLower());
            }

            if (request.LastName != null)
            {
                user = user.Where(u => u.LastName.ToLower() == request.LastName.Trim().ToLower());
            }


            return user.Select(a => new GetUserDto
            {
                Id = a.Id,
                FirstName = a.FirstName,
                LastName = a.LastName,
                Email = a.Email,
                Username = a.Username,
                Password = a.Password,

            });


        }
    }
}
