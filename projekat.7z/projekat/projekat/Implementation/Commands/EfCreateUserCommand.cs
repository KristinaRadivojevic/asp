﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Application.Commands;
using Application.DTO;
using Application.Exceptions;
using Domain;
using DataAccess;

namespace Commands
{
    public class EfCreateUserCommand : ICreateUserCommand
    {
        private readonly TelefoniContext _context;

        public EfCreateUserCommand(TelefoniContext context)
        {
            _context = context;
        }

        public void Execute(CreateUserDto request)
        {

            _ = _context.Users.Add(new User
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Username = request.Username,
                Password = request.Password,
                RoleId = request.RoleId
            });

            _context.SaveChanges();
        }
    }
}
