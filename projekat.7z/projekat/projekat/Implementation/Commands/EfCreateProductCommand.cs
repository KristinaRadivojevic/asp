﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Application.Commands;
using Application.DTO;
using Application.Exceptions;
using Domain;
using DataAccess;

namespace Commands
{
    public class EfCreateProductCommand : ICreateProductCommand
    {
        private readonly TelefoniContext _context;

        public EfCreateProductCommand(TelefoniContext context)
        {
            _context = context;
        }

        public void Execute(CreateProductDto request)
        {
            if (!_context.Categories.Any(c => c.Id == request.CategoryId))
            {
                throw new EntityNotFoundException("Category");

            }

            if (!_context.Images.Any(i => i.Id == request.ImageId))
            {
                throw new EntityNotFoundException("Image");

            }

            _context.Products.Add(new Product
            {
                CreatedAt = DateTime.Now,
                ProductName = request.ProductName,
                Description = request.Description,
                Price = request.Price,
                CategoryId = request.CategoryId,
                ImageId = request.ImageId
            });

            _context.SaveChanges();
        }
    }
}
