﻿using Application.DTO;
using Application.Exceptions;
using DataAccess;
using Application.Commands;

namespace Commands
{
    public class EfGetOneUserCommand : IGetOneUserCommand
    {
        private readonly TelefoniContext _context;

        public EfGetOneUserCommand(TelefoniContext context)
        {
            _context = context;
        }

        public GetUserDto Execute(int request)
        {
            var user = _context.Users.Find(request);

            if (user == null)
            {
                throw new EntityNotFoundException("User");
            }

            return new GetUserDto
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                Username = user.Username,
                Password = user.Password,
            };
        }
    }
}
