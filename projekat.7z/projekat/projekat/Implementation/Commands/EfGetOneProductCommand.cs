﻿using Application.DTO;
using DataAccess;
using Application.Exceptions;
using Application.Commands;

namespace Commands
{
    public class EfGetOneProductCommand : IGetOneProductCommand
    {
        private readonly TelefoniContext _context;

        public EfGetOneProductCommand(TelefoniContext context)
        {
            _context = context;
        }

        public GetProductDto Execute(int request)
        {

            var product = _context.Products.Find(request);

            if (product == null)
            {
                throw new EntityNotFoundException("Product");
            }

            return new GetProductDto
            {
                Id = product.Id,
                ProductName = product.ProductName,
                Description = product.Description,
                Price = product.Price

            };

        }

    }
}
