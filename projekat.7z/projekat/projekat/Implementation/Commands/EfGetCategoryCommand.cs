﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Application.Commands;
using Application.DTO;
using Application.Searches;
using DataAccess;

namespace Commands
{
    public class EfGetCategoryCommand : IGetCategoryCommand
    {

        private readonly TelefoniContext _context;

        public EfGetCategoryCommand(TelefoniContext context)
        {
            _context = context;
        }

        public IEnumerable<GetCategoryDto> Execute(CategorySearches request)
        {
            var category = _context.Categories.AsQueryable();

            if (request.CategoryName != null)
            {
                category = category.Where(c => c.CategoryName.ToLower() == request.CategoryName.Trim().ToLower());
            }

            return category.Select(c => new GetCategoryDto
            {
                Id = c.Id,
                CategoryName = c.CategoryName
            });
        }
    }
}
