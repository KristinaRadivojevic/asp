﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.Commands;
using Application.Exceptions;
using DataAccess;

namespace Commands
{
    public class EfDeleteImageCommand : IDeleteImageCommand
    {
        private readonly TelefoniContext _context;

        public EfDeleteImageCommand(TelefoniContext context)
        {
            _context = context;
        }

        public void Execute(int request)
        {
            var image = _context.Images.Find(request);

            if (image == null)
            {
                throw new EntityNotFoundException("Image");
            }

            _context.Images.Remove(image);

            _context.SaveChanges();
        }
    }
}
