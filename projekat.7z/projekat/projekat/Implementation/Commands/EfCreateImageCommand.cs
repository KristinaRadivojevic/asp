﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.Commands;
using Application.DTO;
using Domain;
using DataAccess;

namespace Commands
{
    public class EfCreateImageCommand : ICreateImageCommand
    {
        private readonly TelefoniContext _context;

        public EfCreateImageCommand(TelefoniContext context)
        {
            _context = context;
        }

        public void Execute(CreateImageDto request)
        {
            _context.Images.Add(new Image
            {

                CreatedAt = DateTime.Now,
                Src = request.Src,
                Alt = request.Alt,
                Title = request.Title
            });

            _context.SaveChanges();
        }
    }
}

