﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Application;
using Application.Commands;
using Application.DTO;
using Application.Exceptions;
using DataAccess;

namespace Commands
{
    public class EfEditUserCommand : IEditUserCommand
    {
        private readonly TelefoniContext _context;

        public EfEditUserCommand(TelefoniContext context)
        {
            _context = context;
        }

        public void Execute(CreateUserDto request)
        {
            var user = _context.Users.Find(request.Id);

            if (user == null)
            {
                throw new EntityNotFoundException("User");
            }

            

            user.ModifiedAt = DateTime.Now;
            user.FirstName = request.FirstName;
            user.LastName = request.LastName;
            user.Email = request.Email;
            user.Username = request.Username;
            user.Password = request.Password;
            user.RoleId = request.RoleId;

            _context.SaveChanges();
        }

        void ICommand<CreateCategoryDto>.Execute(CreateCategoryDto request)
        {
            throw new NotImplementedException();
        }
    }
}
