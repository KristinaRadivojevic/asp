﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.Commands;
using Application.Exceptions;
using DataAccess;
using Domain;

namespace Implementation.Commands
{
    public class EfDeleteOrderCommand : IDeleteOrderCommand
    {
        private readonly TelefoniContext _context;

        public EfDeleteOrderCommand(TelefoniContext context)
        {
            _context = context;
        }
        public int Id => 13;

        public string Name => "Deleting order";

        public void Execute(int request)
        {
            var order = _context.Order.Find(request);

            if (order == null)
            {
                throw new EntityNotFoundException(request, typeof(Order));
            }

            order.IsActive = false;
            order.IsDeleted = true;
            order.DeletedAt = DateTime.Now;

            _context.SaveChanges();
        }
    }
}