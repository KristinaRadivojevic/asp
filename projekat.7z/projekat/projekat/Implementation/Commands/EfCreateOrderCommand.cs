﻿using AutoMapper;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using Application;
using Application.Commands;
using DataAccess;
using Domain;
using Implementation.Validators;
using Application.DTO;
using Watches.Implementation.Validators;

namespace Implementation.Commands
{
    public class EfCreateOrderCommand : ICreateOrderCommand
    {
        private readonly TelefoniContext _context;
        private readonly CreateOrderValidator _validator;

        public EfCreateOrderCommand(TelefoniContext context, CreateOrderValidator validator)
        {
            _context = context;
            _validator = validator;
        }
        public int Id => 14;

        public string Name => "Create new order";

        public void Execute(CreateOrderDto dto)
        {
            _validator.ValidateAndThrow(dto);

            var order = new Order
            {
                UserId = dto.Id,
                Address = dto.Address,
                OrderDate = dto.OrderDate
            };

            foreach (var item in dto.Items)
            {
                var product = _context.Products.Find(item.ProductId);

                product.Quantity -= item.Quantity;

                order.OrderLines.Add(new OrderLine
                {
                    ProductId = item.ProductId,
                    Quantity = item.Quantity,
                    Name = product.ProductName,
                    Price = product.Price
                });
            }


            _context.Order.Add(order);

            _context.SaveChanges();
        }

        void ICommand<CreateOrderDto>.Execute(CreateOrderDto request)
        {
            throw new NotImplementedException();
        }
    }
}