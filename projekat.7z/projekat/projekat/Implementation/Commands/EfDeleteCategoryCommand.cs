﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.Commands;
using Application.Exceptions;
using DataAccess;

namespace Commands
{
    public class EfDeleteCategoryCommand : IDeleteCategoryCommand
    {
        private readonly TelefoniContext _context;

        public EfDeleteCategoryCommand(TelefoniContext context)
        {
            _context = context;
        }

        public void Execute(int request)
        {
            var category = _context.Categories.Find(request);

            if (category == null)
            {
                throw new EntityNotFoundException("Category");
            }

            _context.Categories.Remove(category);

            _context.SaveChanges();
        }
    }
}
