﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.Commands;
using Application.Exceptions;
using DataAccess;

namespace Commands
{
    public class EfDeleteProductCommand : IDeleteProductCommand
    {
        private readonly TelefoniContext _context;

        public EfDeleteProductCommand(TelefoniContext context)
        {
            _context = context;
        }

        public void Execute(int request)
        {
            var product = _context.Products.Find(request);

            if (product == null)
            {
                throw new EntityNotFoundException("Product");
            }

            _context.Products.Remove(product);

            _context.SaveChanges();
        }
    }
}
