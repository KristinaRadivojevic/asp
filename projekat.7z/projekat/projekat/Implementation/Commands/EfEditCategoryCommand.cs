﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.Commands;
using Application.DTO;
using Application.Exceptions;
using DataAccess;

namespace Commands
{
    public class EfEditCategoryCommand : IEditCategoryCommand
    {
        private readonly TelefoniContext _context;

        public EfEditCategoryCommand(TelefoniContext context)
        {
            _context = context;
        }

        public void Execute(CreateCategoryDto request)
        {
            var category = _context.Categories.Find(request.Id);

            if (category == null)
            {
                throw new EntityNotFoundException("Category");
            }

            category.ModifiedAt = DateTime.Now;
            category.CategoryName = request.CategoryName;


            _context.SaveChanges();
        }
    }
}
