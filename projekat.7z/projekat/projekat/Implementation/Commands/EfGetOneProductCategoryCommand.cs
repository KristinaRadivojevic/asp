﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.Commands;
using Application.DTO;
using Application.Exceptions;
using DataAccess;

namespace Commands
{
    public class EfGetOneCategoryCommand : IGetOneCategoryCommand
    {
        private readonly TelefoniContext _context;

        public EfGetOneCategoryCommand(TelefoniContext context)
        {
            _context = context;
        }

        public GetCategoryDto Execute(int request)
        {
            var category = _context.Categories.Find(request);

            if (category == null)
            {
                throw new EntityNotFoundException("Category");
            }

            return new GetCategoryDto
            {
                Id = category.Id,
                CategoryName = category.CategoryName


            };
        }
    }
}
