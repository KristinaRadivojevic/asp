﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.Commands;
using Application.DTO;
using Domain;
using DataAccess;

namespace Commands
{
    public class EfCreateCategoryCommand : ICreateCategoryCommand
    {

        private readonly TelefoniContext _context;

        public EfCreateCategoryCommand(TelefoniContext context)
        {
            _context = context;
        }

        public void Execute(CreateCategoryDto request)
        {
            _context.Categories.Add(new Category
            {
                CreatedAt = DateTime.Now,
                CategoryName = request.CategoryName
            });


            _context.SaveChanges();
        }
    }
}

