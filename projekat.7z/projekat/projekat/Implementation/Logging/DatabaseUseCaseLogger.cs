﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using Application;
using DataAccess;

namespace Watches.Implementation.Logging
{
    public class DatabaseUseCaseLogger : IUseCaseLogger
    {
        private readonly TelefoniContext _context;

        public DatabaseUseCaseLogger(TelefoniContext context)
        {
            _context = context;
        }

        public void Log(IUseCase useCase, IApplicationActor actor, object UseCaseData)
        {
            _context.UseCaseLog.Add(new Domain.UseCaseLog
            {
                Actor = actor.Identity,
                Date = DateTime.UtcNow,
                UseCaseName = useCase.Name,
                Data = JsonConvert.SerializeObject(UseCaseData)
            });

            _context.SaveChanges();
        }
    }
}