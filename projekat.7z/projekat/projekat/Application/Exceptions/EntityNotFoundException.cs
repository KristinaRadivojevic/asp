﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Exceptions
{
    public class EntityNotFoundException : Exception
    {
        private int id;
        private Type type;

        public EntityNotFoundException(string entity) : base($"{entity} doesn't exist.")
        {

        }

        public EntityNotFoundException()
        {

        }

        public EntityNotFoundException(int id, Type type)
        {
            this.id = id;
            this.type = type;
        }
    }
}
