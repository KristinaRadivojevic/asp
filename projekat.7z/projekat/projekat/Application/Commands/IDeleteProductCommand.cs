﻿using Application;

namespace Application.Commands
{
    public interface IDeleteProductCommand : ICommand<int>
    {
    }
}
