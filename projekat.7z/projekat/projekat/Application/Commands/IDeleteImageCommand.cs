﻿using Application;

namespace Application.Commands
{
    public interface IDeleteImageCommand : ICommand<int>
    {
    }
}
