﻿using Application;
using Application.DTO;

namespace Application.Commands
{
    public interface IGetOneProductCommand : ICommand<int, GetProductDto>
    {
    }
}
