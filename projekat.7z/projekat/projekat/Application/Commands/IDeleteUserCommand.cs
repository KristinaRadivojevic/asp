﻿using Application;

namespace Application.Commands
{
    public interface IDeleteUserCommand : ICommand<int>
    {
    }
}
