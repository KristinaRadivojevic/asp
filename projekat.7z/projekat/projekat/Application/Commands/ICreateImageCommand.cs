﻿using Application;
using Application.DTO;

namespace Application.Commands
{
    public interface ICreateImageCommand : ICommand<CreateImageDto>
    {
    }
}
