﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.DTO;
using Application.Response;
using Application.Searches;

namespace Application.Commands
{
    public interface IGetProductCommandPaginate : ICommand<ProductSearches, PagedResponse<GetProductDto>>
    {
    }
}
