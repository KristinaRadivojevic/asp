﻿using Application;
using Application.DTO;

namespace Application.Commands
{
    public interface IGetOneUserCommand : ICommand<int, GetUserDto>
    {
    }
}
