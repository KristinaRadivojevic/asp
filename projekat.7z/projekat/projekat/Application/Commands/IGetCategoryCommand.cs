﻿using System.Collections.Generic;
using Application;
using Application.DTO;
using Application.Searches;

namespace Application.Commands
{
    public interface IGetCategoryCommand : ICommand<CategorySearches, IEnumerable<GetCategoryDto>>
    {
    }
}
