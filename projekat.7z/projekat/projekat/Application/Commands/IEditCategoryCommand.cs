﻿using Application;
using Application.DTO;

namespace Application.Commands
{
    public interface IEditCategoryCommand : ICommand<CreateCategoryDto>
    {
    }
}
