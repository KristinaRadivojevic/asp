﻿using Application;
using Application.DTO;

namespace Application.Commands
{
    public interface ICreateCategoryCommand : ICommand<CreateCategoryDto>
    {
    }
}
