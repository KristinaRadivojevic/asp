﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.DTO;
using Application.Searches;

namespace Application.Commands
{
    public interface IGetProductCommand : ICommand<ProductSearches, IEnumerable<GetProductDto>>
    {

    }
}
