﻿using Application;
using Application.DTO;

namespace Application.Commands
{
    public interface IEditUserCommand : ICommand<CreateCategoryDto>
    {
        void Execute(CreateUserDto dto);
    }
}
