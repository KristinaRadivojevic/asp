﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.DTO;
using Application.Searches;

namespace Application.Commands
{
    public interface IGetUserCommand : ICommand<UserSearches, IEnumerable<GetUserDto>>
    {
    }
}
