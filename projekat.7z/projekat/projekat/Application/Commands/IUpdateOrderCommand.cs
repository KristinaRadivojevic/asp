﻿using System;
using System.Collections.Generic;
using System.Text;
using Application;
using Application.DTO;

namespace Application.Commands
{
    public interface IUpdateOrderCommand : ICommand<int, CreateOrderDto>
    {
    }
}