﻿using Application;
using Application.DTO;

namespace Application.Commands
{
    public interface IEditProductCommand : ICommand<CreateCategoryDto>
    {
        void Execute(CreateProductDto dto);
    }
}
