﻿using Application;

namespace Application.Commands
{
    public interface IDeleteCategoryCommand : ICommand<int>
    {
    }
}
