﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Searches
{
    public class CategorySearches
    {
        public string CategoryName { get; set; }
    }

}
