﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Searches
{
    public class ImageSearches
    {
        public string Alt { get; set; }

    }
}
