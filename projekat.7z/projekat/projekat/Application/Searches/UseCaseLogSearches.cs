﻿using System;
using System.Collections.Generic;
using System.Text;
using Application;
using Application.Response;

namespace Application.Searches
{
    public class UseCaseLogSearch : PagedSearch
    {
        public string Actor { get; set; }
        public string UseCaseName { get; set; }
    }
}