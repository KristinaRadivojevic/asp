﻿using System;
namespace Application
{
   
        public interface ICommand<TRequest>
    {
            void Execute(TRequest request);
        }

        public interface ICommand<TRequest, TResponse> where TResponse : class
        {
            TResponse Execute(TRequest request);
        }
        public interface IQuery<TSearch, TResult> : IUseCase
        {
            TResult Execute(TSearch search);
        }

        public interface IUseCase
        {
            int Id { get; }
            string Name { get; }
        }

}
