﻿using System;
using System.Collections.Generic;

namespace Domain
{
    public class User
    {
        public readonly object CreatedAt;
        public readonly object UserUseCases;
        public readonly int Id;
        public bool IsDeleted;

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }

        public int RoleId { get; set; }

        public virtual ICollection<UserUseCase> UserUseCase { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
        public DateTime ModifiedAt { get; set; }

        
    }
}
