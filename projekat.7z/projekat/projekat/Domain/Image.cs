﻿using System;
namespace Domain
{
    public class Image : Entity
    {
        public string Src { get; set; }

        public string Alt { get; set; }

        public string Title { get; set; }

        public Product Product { get; set; }
    }
}
